/**
 * Logins class representing the entity for user logins.
 */
package ua.restaurant.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of user logins and is annotated as an entity for database mapping.
 * It includes fields such as id (unique identifier), login (user login name),
 * password (user password), email (user email), role (user role), and time (creation time).
 */
@Entity
@Table( name="login",
        uniqueConstraints={@UniqueConstraint(columnNames={"login"})})
public class Logins {

    /**
     * Long representing the unique identifier of the user login.
     */
    @Id
    @GeneratedValue(generator = "sequence-login-id")
    @GenericGenerator(
            name = "sequence-login-id",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "sequence_name", value = "login_id_seq"),
                    @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                    @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
            })
    @Column(name = "id")
    private Long id;

    /**
     * String representing the user login name, constrained to be unique.
     */
    @Column(name = "login")
    private String login;

    /**
     * String representing the user password.
     */
    @Column(name = "password")
    private String password;

    /**
     * String representing the user email.
     */
    @Column(nullable = false)
    private String email;

    /**
     * Enum representing the user role, with values from the RoleType enumeration.
     */
    @Column(name = "role")
    @Enumerated(EnumType.STRING)
    private RoleType role;

    /**
     * LocalDateTime representing the creation time of the user login.
     */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime time;
}
