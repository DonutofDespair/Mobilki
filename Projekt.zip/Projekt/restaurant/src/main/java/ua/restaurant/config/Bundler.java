/**
 * Bundler class responsible for configuring message sources and providing methods to retrieve messages.
 */
package ua.restaurant.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import java.util.Locale;

@Configuration
public class Bundler {

    private final MessageSource messageSource;
    private final MessageSource logSource;

    /**
     * Constructor for Bundler, injecting MessageSource and logSource dependencies.
     *
     * @param messageSource The MessageSource for application messages.
     * @param logSource     The MessageSource for log messages.
     */
    @Autowired
    public Bundler(MessageSource messageSource, MessageSource logSource) {
        this.messageSource = messageSource;
        this.logSource = logSource;
    }

    /**
     * Configures a LocalValidatorFactoryBean bean with the provided message source for validation messages.
     *
     * @return An instance of LocalValidatorFactoryBean configured with the message source.
     */
    @Bean
    public LocalValidatorFactoryBean getValidator() {
        LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
        bean.setValidationMessageSource(messageSource);
        return bean;
    }

    /**
     * Retrieves the application message for the given key and current locale.
     *
     * @param msg The key to look up the application message.
     * @return The application message for the given key.
     */
    public String getMsg(String msg) {
        return messageSource.getMessage(msg, null, LocaleContextHolder.getLocale());
    }

    /**
     * Retrieves the log message for the given key and sets the locale to English.
     *
     * @param msg The key to look up the log message.
     * @return The log message for the given key.
     */
    public String getLogMsg(String msg) {
        return logSource.getMessage(msg, null, Locale.ENGLISH);
    }
}
