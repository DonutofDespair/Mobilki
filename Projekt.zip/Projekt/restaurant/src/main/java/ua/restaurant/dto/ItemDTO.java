/**
 * ItemDTO class representing the data transfer object for various operations involving items.
 */
package ua.restaurant.dto;

import lombok.*;

import javax.validation.constraints.Min;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of items involved in different operations.
 * It contains a single field itemId, which is validated to ensure it is greater than or equal to 1.
 * This object is used for operations such as confirming, payment, adding a dish to the basket, and deleting a dish from the basket.
 */
public class ItemDTO {

    /**
     * Long representing the unique identifier of the item.
     */
    @Min(value = 1, message = "{error.itemDTO}")
    Long itemId;
}
