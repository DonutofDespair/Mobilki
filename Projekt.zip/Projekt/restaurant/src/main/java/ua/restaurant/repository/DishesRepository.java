package ua.restaurant.repository;

import lombok.NonNull;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import ua.restaurant.entity.Dishes;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Repository interface for managing {@link Dishes} entities in the database.
 */
public interface DishesRepository extends JpaRepository<Dishes, Long> {

    /**
     * Retrieves a page of dishes based on the specified category ID.
     *
     * @param categoryId The ID of the category to filter by.
     * @param pageable   The pagination information.
     * @return A page of dishes within the specified category.
     */
    Page<Dishes> findByCategories_Id(Long categoryId, Pageable pageable);

    /**
     * Retrieves a dish by its ID.
     *
     * @param id The ID of the dish to retrieve.
     * @return An optional containing the dish if found.
     */
    @Nonnull Optional<Dishes> findById(@Nonnull Long id);

    /**
     * Deletes a dish by its ID.
     *
     * @param id The ID of the dish to delete.
     */
    void deleteById(@Nonnull Long id);

    /**
     * Retrieves a dish by its English name.
     *
     * @param name The English name of the dish.
     * @return An optional containing the dish if found.
     */
    Optional<Dishes> findByNameEn(@NonNull String name);
}
