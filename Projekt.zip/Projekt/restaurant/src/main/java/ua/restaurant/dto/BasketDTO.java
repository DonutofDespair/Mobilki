/**
 * BasketDTO class representing the data transfer object for the user's basket.
 */
package ua.restaurant.dto;

import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of the user's basket and is used as a data transfer object (DTO).
 * It contains a list of DishDTO objects representing the dishes in the basket and the total price of the basket.
 * No validation is applied, and the object is used to transfer data to the basket page.
 */
public class BasketDTO {

    /**
     * List of DishDTO objects representing the dishes in the basket.
     */
    private List<DishDTO> dishes;

    /**
     * BigDecimal representing the total price of the basket.
     */
    private BigDecimal totalPrice;
}
