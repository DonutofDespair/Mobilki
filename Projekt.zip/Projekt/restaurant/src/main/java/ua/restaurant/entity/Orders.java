/**
 * Orders class representing the entity for user orders.
 */
package ua.restaurant.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of user orders and is annotated as an entity for database mapping.
 * It includes fields such as id (unique identifier), login (user login associated with the order),
 * totalPrice (total price of the order), status (order status), and time (creation time).
 */
@Entity
public class Orders {

    /**
     * Long representing the unique identifier of the order.
     */
    @Id
    @GeneratedValue(generator = "sequence-orders-id")
    @GenericGenerator(
            name = "sequence-orders-id",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "sequence_name", value = "orders_id_seq"),
                    @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                    @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
            })
    @Column(name = "id")
    private Long id;

    /**
     * Logins representing the user login associated with the order.
     * FetchType.EAGER is used for eager loading of associated entities.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "login_id", referencedColumnName = "id")
    private Logins login;

    /**
     * BigDecimal representing the total price of the order.
     */
    private BigDecimal totalPrice;

    /**
     * Enum representing the status of the order, with values from the Status enumeration.
     */
    @Enumerated(EnumType.STRING)
    private Status status;

    /**
     * LocalDateTime representing the creation time of the order.
     */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime time;
}
