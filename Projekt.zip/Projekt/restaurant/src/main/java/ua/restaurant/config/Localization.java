/**
 * Localization class responsible for configuring locale resolver for internationalization (i18n).
 */
package ua.restaurant.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import java.util.Locale;

@Configuration
public class Localization implements WebMvcConfigurer {

    /**
     * Configures a SessionLocaleResolver bean as the locale resolver for the application.
     *
     * @return An instance of SessionLocaleResolver configured with the default locale set to English.
     */
    @Bean
    public LocaleResolver localeResolver() {
        SessionLocaleResolver slr = new SessionLocaleResolver();
        slr.setDefaultLocale(Locale.ENGLISH); // Sets the default locale to English.
        return slr;
    }
}
