package ua.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ua.restaurant.entity.Orders;
import ua.restaurant.entity.Status;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for managing {@link Orders} entities in the database.
 */
public interface OrdersRepository extends JpaRepository<Orders, Long> {

    /**
     * Retrieves a list of orders by the user's ID.
     *
     * @param id The ID of the user.
     * @return A list of orders for the specified user.
     */
    List<Orders> findOrdersByLogin_Id(Long id);

    /**
     * Retrieves a list of orders by their ID in ascending order.
     *
     * @return A list of orders by ID.
     */
    List<Orders> findOrdersByOrderByIdAsc();

    /**
     * Retrieves an order by its ID, user ID, and status.
     *
     * @param id      The ID of the order.
     * @param loginId The ID of the user.
     * @param status  The status of the order.
     * @return An optional containing the order if found.
     */
    Optional<Orders> findByIdAndLogin_IdAndStatus(Long id, Long loginId, Status status);

    /**
     * Updates the status of an order.
     *
     * @param id     The ID of the order.
     * @param status The new status for the order.
     */
    @Modifying
    @Query("UPDATE Orders o SET o.status = :status WHERE o.id = :id")
    void updateStatus(@Param(value = "id") Long id,
                      @Param(value = "status") Status status);
}
