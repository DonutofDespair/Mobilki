package ua.restaurant.exceptionHandling;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;

/**
 * Represents an error response structure for API exceptions.
 */
@Getter
@Setter
public class ApiError {

    /**
     * The HTTP status of the response.
     */
    private HttpStatus status;

    /**
     * A general message describing the error.
     */
    private String message;

    /**
     * A list of detailed error messages.
     */
    private List<String> errors;

    /**
     * Constructs an {@code ApiError} object with the specified parameters.
     *
     * @param status  The HTTP status of the response.
     * @param message A general message describing the error.
     * @param errors  A list of detailed error messages.
     */
    public ApiError(HttpStatus status, String message, List<String> errors) {
        super();
        this.status = status;
        this.message = message;
        this.errors = errors;
    }

    /**
     * Constructs an {@code ApiError} object with the specified parameters.
     *
     * @param status The HTTP status of the response.
     * @param message A general message describing the error.
     * @param error A single error message.
     */
    public ApiError(HttpStatus status, String message, String error) {
        super();
        this.status = status;
        this.message = message;
        errors = Arrays.asList(error);
    }
}
