package ua.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.restaurant.entity.Baskets;

import java.util.List;

/**
 * Repository interface for managing {@link Baskets} entities in the database.
 */
public interface BasketRepository extends JpaRepository<Baskets, Long> {

    /**
     * Retrieves a list of baskets associated with a specific user login ID.
     *
     * @param id The ID of the user login.
     * @return List of baskets associated with the given user login ID.
     */
    List<Baskets> findAllByLogin_Id(Long id);

    /**
     * Retrieves a list of baskets based on the ID of the associated dish.
     *
     * @param id The ID of the associated dish.
     * @return List of baskets associated with the given dish ID.
     */
    List<Baskets> findBasketsByDishes_Id(Long id);

    /**
     * Deletes baskets associated with a specific user login ID.
     *
     * @param id The ID of the user login for which baskets should be deleted.
     */
    void deleteByLogin_Id(Long id);
}
