/**
 * LoginDTO class representing the data transfer object for user registration.
 */
package ua.restaurant.dto;

import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of user registration data and is used as a data transfer object (DTO).
 * It contains the login, email, and password fields, each with specific validation constraints.
 * This object is used for the user registration process.
 */
public class LoginDTO {

    /**
     * String representing the user's login.
     */
    @NotBlank(message = "{error.signup.login}")
    private String login;

    /**
     * String representing the user's email, validated using a regular expression.
     */
    @Pattern(regexp = "^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,6}$",
            message = "{error.signup.email}")
    private String email;

    /**
     * String representing the user's password, validated using a regular expression.
     */
    @NotBlank
    @Pattern(regexp = "^[a-z0-9._%+-]{2,6}$",
            message = "{error.signup.password}")
    private String password;
}
