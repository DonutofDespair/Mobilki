package ua.restaurant.security;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import ua.restaurant.dto.LoginDTO;
import ua.restaurant.entity.Logins;
import ua.restaurant.entity.RoleType;
import ua.restaurant.service.LoginService;

import javax.annotation.PostConstruct;

/**
 * Custom implementation of Spring Security UserDetailsService for loading user details during authentication.
 */
@Slf4j
@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    private final LoginService loginService;

    /**
     * Constructs a UserDetailsServiceImpl with the provided LoginService.
     *
     * @param loginService The LoginService for user-related operations.
     */
    @Autowired
    private UserDetailsServiceImpl(LoginService loginService) {
        this.loginService = loginService;
    }

    /**
     * Initializes the UserDetailsServiceImpl by creating a default manager user if not already present.
     */
    @PostConstruct
    public void init() {
        if (!loginService.findByUserLogin("manager").isPresent()) {
            loginService.saveNewUser(LoginDTO.builder()
                    .login("manager")
                    .password("password")
                    .email("neksus509@gmail.com")
                    .build(), RoleType.ROLE_MANAGER);
        }
    }

    /**
     * Loads user details by the provided username.
     *
     * @param username The username for which to load user details.
     * @return UserDetails containing information about the user.
     * @throws UsernameNotFoundException If the user with the given username is not found.
     */
    @Override
    public UserDetails loadUserByUsername(@NonNull String username) throws UsernameNotFoundException {
        Logins login = loginService.findByUserLogin(username).orElseThrow(
                () -> new UsernameNotFoundException("Could not find user: " + username)
        );
        log.info(login.getLogin());

        return new UserDetailsImpl(login);
    }
}
