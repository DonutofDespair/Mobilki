/**
 * Dishes class representing the entity for dishes.
 */
package ua.restaurant.entity;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of dishes and is annotated as an entity for database mapping.
 * It includes fields such as id (unique identifier), nameEn (dish name in English),
 * price (dish price), categories (associated with Categories entity), and time (creation time).
 */
@Entity
public class Dishes {

    /**
     * Long representing the unique identifier of the dish.
     */
    @Id
    @GeneratedValue(generator = "sequence-dishes-id")
    @GenericGenerator(
            name = "sequence-dishes-id",
            strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "sequence_name", value = "dishes_id_seq"),
                    @org.hibernate.annotations.Parameter(name = "initial_value", value = "1"),
                    @org.hibernate.annotations.Parameter(name = "increment_size", value = "1")
            })
    @Column(name = "id")
    private Long id;

    /**
     * String representing the dish name in English, with a pattern validation.
     */
    @Pattern(regexp = "^[a-zA-z0-9 -]+$",
            message = "{error.dish.name_en}")
    @Column(name = "name_en")
    private String nameEn;

    /**
     * BigDecimal representing the price of the dish with a minimum value validation.
     */
    @Min(value = 1, message = "{error.dish.price}")
    @Column(nullable = false)
    private BigDecimal price;

    /**
     * Categories entity representing the associated category of the dish.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id", referencedColumnName = "id")
    private Categories categories;

    /**
     * LocalDateTime representing the creation time of the dish.
     */
    private LocalDateTime time;
}
