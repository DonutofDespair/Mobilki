/**
 * DishDTO class representing the data transfer object for dishes.
 */
package ua.restaurant.dto;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of dishes and is used as a data transfer object (DTO).
 * It contains the id, name, price, and category fields.
 * No validation is applied, and the object is intended for internal use within the orders service.
 */
public class DishDTO {

    /**
     * Long representing the dish's unique identifier.
     */
    private Long id;

    /**
     * String representing the name of the dish.
     */
    private String name;

    /**
     * BigDecimal representing the price of the dish.
     */
    private BigDecimal price;

    /**
     * CategoryDTO representing the category of the dish.
     */
    private CategoryDTO category;
}
