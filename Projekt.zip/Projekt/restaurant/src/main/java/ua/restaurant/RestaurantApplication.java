package ua.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main class for starting the Spring Boot application.
 */
@SpringBootApplication
public class RestaurantApplication {

    /**
     * Main method to launch the Spring Boot application.
     *
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        SpringApplication.run(RestaurantApplication.class, args);
    }
}
