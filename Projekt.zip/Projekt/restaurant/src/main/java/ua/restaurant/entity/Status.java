/**
 * Enumeration representing the different statuses of orders in the system.
 */
package ua.restaurant.entity;

/**
 * The Status enumeration represents the possible statuses of orders in the system.
 * It includes statuses such as NEW, PAYED, PAYMENT_CONFIRM, COOKING, DELIVERY, and DONE.
 * The enumeration also provides a method to get the next status in the sequence.
 */
public enum Status {
    /**
     * Represents the status of a new order.
     */
    NEW,

    /**
     * Represents the status of a paid order.
     */
    PAYED,

    /**
     * Represents the status of a payment-confirmed order.
     */
    PAYMENT_CONFIRM,

    /**
     * Represents the status of an order being cooked.
     */
    COOKING,

    /**
     * Represents the status of an order being delivered.
     */
    DELIVERY,

    /**
     * Represents the status of a completed/done order.
     */
    DONE;

    private static final Status[] statuses = values();

    /**
     * Gets the next status in the sequence.
     *
     * @return The next status in the sequence.
     */
    public Status next() {
        return statuses[(this.ordinal() + 1) % statuses.length];
    }
}
