package ua.restaurant.utils;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import ua.restaurant.entity.Logins;
import ua.restaurant.security.UserDetailsImpl;

import java.util.Locale;

/**
 * Helper class containing methods to retrieve information from the application context.
 */
public class ContextHelpers {

    /**
     * Gets the current language from LocaleContextHolder.
     *
     * @return {@code true} if the current language is English, {@code false} otherwise.
     */
    public static boolean isLocaleEnglish() {
        return LocaleContextHolder.getLocale().equals(Locale.ENGLISH);
    }

    /**
     * Gets the authorized user from SecurityContextHolder.
     *
     * @return The Login entity representing the authorized user.
     */
    public static Logins getAuthorizedLogin() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        UserDetailsImpl userDetails = (UserDetailsImpl) auth.getPrincipal();

        return userDetails.getLogin();
    }
}

