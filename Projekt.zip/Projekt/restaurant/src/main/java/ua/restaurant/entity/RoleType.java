/**
 * Enumeration representing the roles that can be assigned to users.
 */
package ua.restaurant.entity;

/**
 * The RoleType enumeration represents different roles that can be assigned to users.
 * It includes roles such as ROLE_ADMIN, ROLE_MANAGER, and ROLE_CUSTOMER.
 * These roles can be used to define the level of access and permissions for users in the system.
 */
public enum RoleType {
    /**
     * Represents the role of an administrator with high-level access and permissions.
     */
    ROLE_ADMIN,

    /**
     * Represents the role of a manager with specific managerial access and permissions.
     */
    ROLE_MANAGER,

    /**
     * Represents the role of a customer with basic access and permissions.
     */
    ROLE_CUSTOMER
}
