package ua.restaurant.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ua.restaurant.config.Bundler;
import ua.restaurant.dto.DishDTO;
import ua.restaurant.entity.*;
import ua.restaurant.repository.*;
import ua.restaurant.utils.Constants;
import ua.restaurant.utils.ContextHelpers;
import ua.restaurant.utils.Mapper;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Service class for managing orders, including creation, retrieval, and confirmation.
 */
@Slf4j
@Service
public class OrdersService {
    private final OrdersRepository ordersRepository;
    private final BasketRepository basketRepository;
    private final Bundler bundler;

    @Autowired
    public OrdersService(OrdersRepository ordersRepository,
                         BasketRepository basketRepository,
                         Bundler bundler) {
        this.ordersRepository = ordersRepository;
        this.basketRepository = basketRepository;
        this.bundler = bundler;
    }

    /**
     * Retrieves all orders for the currently logged-in user.
     *
     * @return List of user orders
     */
    public List<Orders> findAllUserOrders() {
        return ordersRepository.findOrdersByLogin_Id(
                ContextHelpers.getAuthorizedLogin().getId());
    }

    /**
     * Retrieves all orders for the manager's order page.
     *
     * @return List of all orders
     */
    public List<Orders> findAllOrders() {
        return ordersRepository.findOrdersByOrderByIdAsc();
    }

    /**
     * Creates an order from the user's basket items and clears the basket.
     *
     * @return Saved order entity
     * @throws NoSuchElementException if the basket is empty or if deletion/saving fails
     */
    @Transactional
    public Orders saveNewItem() throws NoSuchElementException {
        Logins user = ContextHelpers.getAuthorizedLogin();

        List<Baskets> basketsItems = basketRepository.findAllByLogin_Id(user.getId());
        if (basketsItems.isEmpty()) {
            throw new NoSuchElementException(bundler.getLogMsg(Constants.BASKET_ALL_EMPTY));
        }
        List<DishDTO> dishes = Mapper.basketToDishesDTO(basketsItems);
        BigDecimal total = Mapper.getTotalPrice(dishes);

        basketRepository.deleteByLogin_Id(user.getId());
        log.info(bundler.getLogMsg(Constants.BASKET_DELETE_ALL));

        return ordersRepository.save(Orders.builder()
                .login(user)
                .totalPrice(total)
                .status(Status.NEW)
                .time(LocalDateTime.now())
                .build());
    }

    /**
     * Manager confirms the next order stage.
     *
     * @param id Given order ID
     * @return True if confirmation is successful
     */
    @Transactional
    public boolean confirm(Long id) {
        Orders order = ordersRepository.findById(id)
                .orElseThrow(() ->
                        new NoSuchElementException(
                                bundler.getLogMsg(Constants.ORDERS_NOT_FOUND) + id));

        if (!ContextHelpers.getAuthorizedLogin().getRole().equals(RoleType.ROLE_MANAGER) ||
                order.getStatus().equals(Status.DONE) ||
                order.getStatus().equals(Status.NEW)) {
            throw new NoSuchElementException(
                    bundler.getLogMsg(Constants.ORDERS_NOT_FOUND) + id);
        }
        ordersRepository.updateStatus(id, order.getStatus().next());
        return true;
    }

    /**
     * Updates the order status if the user has paid for it.
     *
     * @param id Order ID
     * @return True if the update is successful
     */
    @Transactional
    public boolean payment(Long id) {
        Long loginId = ContextHelpers.getAuthorizedLogin().getId();

        ordersRepository.findByIdAndLogin_IdAndStatus(id, loginId, Status.NEW)
                .orElseThrow(() -> new NoSuchElementException(
                        bundler.getLogMsg(Constants.ORDERS_NOT_FOUND) + id));

        ordersRepository.updateStatus(id, Status.PAYED);
        return true;
    }
}
