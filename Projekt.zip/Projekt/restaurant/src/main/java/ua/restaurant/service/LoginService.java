package ua.restaurant.service;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import ua.restaurant.config.Bundler;
import ua.restaurant.dto.LoginDTO;
import ua.restaurant.entity.Logins;
import ua.restaurant.entity.RoleType;
import ua.restaurant.repository.LoginsRepository;

import java.time.LocalDateTime;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * Service class for managing user logins and registration.
 */
@Slf4j
@Service
public class LoginService {
    private final LoginsRepository loginsRepository;
    private final Bundler bundler;

    @Autowired
    public LoginService(LoginsRepository loginsRepository,
                        Bundler bundler) {
        this.loginsRepository = loginsRepository;
        this.bundler = bundler;
    }

    /**
     * Retrieves a user login by its username.
     *
     * @param login String login
     * @return Optional containing the user login or empty if not found
     */
    public Optional<Logins> findByUserLogin(@NonNull String login) {
        return loginsRepository.findByLogin(login);
    }

    /**
     * Registers a new user.
     *
     * @param loginDTO Parameters of the new user
     * @param role     Role of the new user
     * @return Saved user login entity
     * @throws IllegalArgumentException if the login already exists in the database
     */
    public Logins saveNewUser(@NonNull LoginDTO loginDTO, RoleType role) throws NoSuchElementException {
        try {
            return loginsRepository.save(Logins.builder()
                    .login(loginDTO.getLogin())
                    .email(loginDTO.getEmail())
                    .role(role)
                    .time(LocalDateTime.now())
                    .password(new BCryptPasswordEncoder().encode(loginDTO.getPassword())).build());
        } catch (Exception e) {
            String message = "error.signup.login.exists";
            log.warn(bundler.getLogMsg(message) + loginDTO.getLogin());
            throw new IllegalArgumentException(bundler.getMsg(message) + loginDTO.getLogin());
        }
    }
}
