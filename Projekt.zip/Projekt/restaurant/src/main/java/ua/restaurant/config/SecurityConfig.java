/**
 * SecurityConfig class responsible for configuring Spring Security settings.
 */
package ua.restaurant.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import ua.restaurant.entity.RoleType;
import ua.restaurant.security.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final UserDetailsServiceImpl userDetailsServiceImpl;
    private static final String[] SWAGGER_WHITE_LIST = {
            "/swagger-ui/**",
            "/v2/api-docs",
            "/v3/api-docs/**",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-resources",
            "/swagger-resources/**",
            "/swagger-ui.html",
            "/webjars/**"
    };

    @Autowired
    public SecurityConfig(UserDetailsServiceImpl userDetailsServiceImpl) {
        this.userDetailsServiceImpl = userDetailsServiceImpl;
    }

    /**
     * Configures HTTP security settings.
     *
     * @param http The HttpSecurity object to configure.
     * @throws Exception If an error occurs during configuration.
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/", "/signup", "/api/get/**", "/css/*", "/js/*").permitAll() // Allow access to specific paths without authentication.
                .antMatchers("/manager/**").hasAuthority(RoleType.ROLE_MANAGER.name()) // Allow access to "/manager/**" only for users with ROLE_MANAGER authority.
                .antMatchers(SWAGGER_WHITE_LIST).hasAuthority(RoleType.ROLE_MANAGER.name()) // Allow access to Swagger resources only for users with ROLE_MANAGER authority.
                .anyRequest().authenticated() // All other requests require authentication.
                .and()
                .formLogin()
                .loginPage("/login").permitAll() // Configures the custom login page and allows access without authentication.
                .and()
                .logout()
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout")) // Configures logout settings with a specific request matcher.
                .permitAll(); // Allows access to the logout page without authentication.

    }

    /**
     * Configures authentication settings.
     *
     * @param auth The AuthenticationManagerBuilder object to configure.
     * @throws Exception If an error occurs during configuration.
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth
                .userDetailsService(userDetailsServiceImpl) // Sets the custom user details service.
                .passwordEncoder(passwordEncoder()); // Configures the password encoder for secure password storage.
    }

    /**
     * Creates a BCryptPasswordEncoder bean.
     *
     * @return An instance of BCryptPasswordEncoder.
     */
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
