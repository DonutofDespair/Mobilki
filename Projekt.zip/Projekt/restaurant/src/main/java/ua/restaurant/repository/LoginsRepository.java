package ua.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ua.restaurant.entity.Logins;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Repository interface for managing {@link Logins} entities in the database.
 */
@Repository
public interface LoginsRepository extends JpaRepository<Logins, Long> {

    /**
     * Retrieves a login by its username.
     *
     * @param login The username to search for.
     * @return An optional containing the login if found.
     */
    Optional<Logins> findByLogin(String login);

    /**
     * Retrieves a login by its ID.
     *
     * @param id The ID of the login to retrieve.
     * @return An optional containing the login if found.
     */
    @Nonnull Optional<Logins> findById(@Nonnull Long id);
}
