package ua.restaurant.security;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;

import lombok.*;
import ua.restaurant.entity.Logins;

/**
 * Custom implementation of Spring Security UserDetails for authentication and authorization.
 */
@Data
@Getter
@Setter
@Builder
@NoArgsConstructor
public class UserDetailsImpl implements UserDetails {
    private Logins login;

    /**
     * Constructs a UserDetailsImpl with the given login.
     *
     * @param login The login entity.
     */
    public UserDetailsImpl(Logins login) {
        this.login = login;
    }

    /**
     * Returns the authorities granted to the user.
     *
     * @return A collection of granted authorities.
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        SimpleGrantedAuthority authority =
                new SimpleGrantedAuthority(login.getRole().name());
        return Collections.singletonList(authority);
    }

    /**
     * Returns the password used to authenticate the user.
     *
     * @return The user's password.
     */
    @Override
    public String getPassword() {
        return login.getPassword();
    }

    /**
     * Indicates whether the user's account has expired.
     *
     * @return Always returns true.
     */
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    /**
     * Returns the username used to authenticate the user.
     *
     * @return The user's username.
     */
    @Override
    public String getUsername() {
        return login.getLogin();
    }

    /**
     * Indicates whether the user's account is locked.
     *
     * @return Always returns true.
     */
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    /**
     * Indicates whether the user's credentials (password) has expired.
     *
     * @return Always returns true.
     */
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    /**
     * Indicates whether the user is enabled or disabled.
     *
     * @return Always returns true.
     */
    @Override
    public boolean isEnabled() {
        return true;
    }
}
