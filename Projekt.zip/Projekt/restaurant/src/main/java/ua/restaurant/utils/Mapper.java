package ua.restaurant.utils;

import ua.restaurant.dto.CategoryDTO;
import ua.restaurant.dto.DishDTO;
import ua.restaurant.entity.Baskets;
import ua.restaurant.entity.Categories;
import ua.restaurant.entity.Dishes;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Converts entities to DTO objects.
 */
public class Mapper {

    /**
     * Maps a Dishes entity to a DishDTO.
     *
     * @param d The Dishes entity to map.
     * @return The corresponding DishDTO.
     */
    private static DishDTO dishDTOMapper(Dishes d) {
        return DishDTO.builder()
                .id(d.getId())
                .price(d.getPrice())
                .name(ContextHelpers.isLocaleEnglish()
                        ? d.getNameEn()
                        : "Default Category")
                .category(categoryDTOMapper(d.getCategories()))
                .build();
    }

    /**
     * Maps a Categories entity to a CategoryDTO.
     *
     * @param c The Categories entity to map.
     * @return The corresponding CategoryDTO.
     */
    private static CategoryDTO categoryDTOMapper(Categories c) {
        return CategoryDTO.builder()
                .id(c.getId())
                .category(ContextHelpers.isLocaleEnglish()
                        ? c.getCategoryEn()
                        : "Default Category")  // Replace "Default Category" with your actual default category
                .build();
    }

    /**
     * Converts a list of Dishes entities to a list of DishDTOs.
     *
     * @param list The list of Dishes entities to convert.
     * @return The corresponding list of DishDTOs.
     */
    public static List<DishDTO> dishesToDishesDTO(List<Dishes> list) {
        return list.stream()
                .map(Mapper::dishDTOMapper)
                .collect(Collectors.toList());
    }

    /**
     * Converts a list of Baskets entities to a list of DishDTOs.
     *
     * @param list The list of Baskets entities to convert.
     * @return The corresponding list of DishDTOs.
     */
    public static List<DishDTO> basketToDishesDTO(List<Baskets> list) {
        return list.stream()
                .map(Baskets::getDishes)
                .map(Mapper::dishDTOMapper)
                .collect(Collectors.toList());
    }

    /**
     * Calculates the total price of a list of DishDTOs.
     *
     * @param dishes The list of DishDTOs to calculate the total price.
     * @return The total price as a BigDecimal.
     */
    public static BigDecimal getTotalPrice(List<DishDTO> dishes) {
        return dishes.stream()
                .map(DishDTO::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Converts a list of Categories entities to a list of CategoryDTOs.
     *
     * @param list The list of Categories entities to convert.
     * @return The corresponding list of CategoryDTOs.
     */
    public static List<CategoryDTO> categoriesToCategoriesDTO(List<Categories> list) {
        return list.stream()
                .map(Mapper::categoryDTOMapper)
                .collect(Collectors.toList());
    }

    /**
     * Converts a list of Dishes entities to a list of CategoryDTOs.
     *
     * @param list The list of Dishes entities to convert.
     * @return The corresponding list of CategoryDTOs.
     */
    public static List<CategoryDTO> dishesToCategoriesDTO(List<Dishes> list) {
        return list.stream()
                .filter(distinctByKey(Dishes::getCategories))
                .map(d -> categoryDTOMapper(d.getCategories()))
                .collect(Collectors.toList());
    }

    /**
     * Creates a Predicate to filter distinct elements based on a key.
     *
     * @param keyExtractor The key extraction function.
     * @param <T>          The type of the elements.
     * @return The Predicate to filter distinct elements.
     */
    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }
}
