/**
 * CategoryDTO class representing the data transfer object for dish categories.
 */
package ua.restaurant.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of dish categories and is used as a data transfer object (DTO).
 * It contains the id and category name fields.
 * No validation is applied, and the object is used to transfer data to the main page within PageableDishesDTO.
 */
public class CategoryDTO {

    /**
     * Long representing the category's unique identifier.
     */
    private Long id;

    /**
     * String representing the name of the category.
     */
    private String category;
}
