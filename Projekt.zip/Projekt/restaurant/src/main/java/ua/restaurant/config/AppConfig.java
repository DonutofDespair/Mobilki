/**
 * AppConfig class responsible for configuring application-related beans.
 */
package ua.restaurant.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

@Configuration
public class AppConfig {

    /**
     * Configures a ResourceBundleMessageSource bean for handling application messages.
     *
     * @return An instance of ResourceBundleMessageSource configured for messages.
     */
    @Bean
    public ResourceBundleMessageSource messageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasenames("messages"); // Specifies the base names of the resource bundles.
        source.setDefaultEncoding("UTF-8"); // Sets the default encoding for message properties files.
        source.setUseCodeAsDefaultMessage(true); // Uses the message code as the default message if no message was found.
        return source;
    }

    /**
     * Configures a ResourceBundleMessageSource bean for handling log-related messages.
     *
     * @return An instance of ResourceBundleMessageSource configured for log messages.
     */
    @Bean
    public ResourceBundleMessageSource logSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasenames("log_messages"); // Specifies the base names of the resource bundles for log messages.
        source.setDefaultEncoding("UTF-8"); // Sets the default encoding for log message properties files.
        source.setUseCodeAsDefaultMessage(true); // Uses the message code as the default log message if no message was found.
        return source;
    }
}
