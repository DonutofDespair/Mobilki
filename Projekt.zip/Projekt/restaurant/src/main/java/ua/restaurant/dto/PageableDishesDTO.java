/**
 * PageableDishesDTO class representing the data transfer object for pageable dishes.
 */
package ua.restaurant.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

/*
 * This class represents the structure of pageable dishes and is used as a data transfer object (DTO).
 * It contains lists of DishDTO and CategoryDTO objects, along with fields representing the current page, total pages,
 * sort field, sort direction, and category ID.
 * No validation is applied, and the object is used to transfer data to the main page.
 */
public class PageableDishesDTO {

    /**
     * List of DishDTO objects representing pageable dishes.
     */
    private List<DishDTO> dishes;

    /**
     * List of CategoryDTO objects representing dish categories.
     */
    private List<CategoryDTO> categories;

    /**
     * Integer representing the current page.
     */
    private int currentPage;

    /**
     * Integer representing the total number of pages.
     */
    private int totalPages;

    /**
     * String representing the sort field.
     */
    private String sortField;

    /**
     * String representing the sort direction.
     */
    private String sortDirection;

    /**
     * Long representing the category ID.
     */
    private Long categoryId;
}
