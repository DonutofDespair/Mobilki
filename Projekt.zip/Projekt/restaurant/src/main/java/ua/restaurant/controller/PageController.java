/**
 * PageController class responsible for handling requests related to page navigation in the application.
 */
package ua.restaurant.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PageController {

    /**
     * Maps the "/" endpoint to the main page.
     *
     * @return String representing the main page.
     */
    @RequestMapping("/")
    public String mainPage() {
        return "main";
    }

    /**
     * Maps the "/login" endpoint to the login page.
     *
     * @return String representing the login page.
     */
    @RequestMapping("/login")
    public String loginPage() {
        return "login";
    }

    /**
     * Maps the "/signup" endpoint to the registration page.
     *
     * @return String representing the registration page.
     */
    @RequestMapping("/signup")
    public String registrationPage() {
        return "signup";
    }

    /**
     * Maps the "/basket" endpoint to the basket page.
     *
     * @return String representing the basket page.
     */
    @RequestMapping("/basket")
    public String basketPage() {
        return "basket";
    }

    /**
     * Maps the "/orders" endpoint to the orders page.
     *
     * @return String representing the orders page.
     */
    @RequestMapping("/orders")
    public String ordersPage() {
        return "orders";
    }

    /**
     * Maps the "/payment" endpoint to the payment page.
     *
     * @return String representing the payment page.
     */
    @RequestMapping("/payment")
    public String paymentPage() {
        return "payment";
    }

    /**
     * Maps the "/manager/manage_orders" endpoint to the orders manager page.
     *
     * @return String representing the orders manager page.
     */
    @RequestMapping("/manager/manage_orders")
    public String ordersManagerPage() {
        return "orders_manager";
    }

    /**
     * Maps the "/manager/manage_dishes" endpoint to the dishes manager page.
     *
     * @return String representing the dishes manager page.
     */
    @RequestMapping("/manager/manage_dishes")
    public String dishesManagerPage() {
        return "dishes_manager";
    }

    /**
     * Maps the "/manager/dishes/create" endpoint to the dishes create page.
     *
     * @return String representing the dishes create page.
     */
    @RequestMapping("/manager/dishes/create")
    public String dishesCreate() {
        return "dishes_create";
    }

    /**
     * Maps the "/manager/dishes/update" endpoint to the dishes update page.
     *
     * @return String representing the dishes update page.
     */
    @RequestMapping("/manager/dishes/update")
    public String dishesUpdate() {
        return "dishes_update";
    }
}
