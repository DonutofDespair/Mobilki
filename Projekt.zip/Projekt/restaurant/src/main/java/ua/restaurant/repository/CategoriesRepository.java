package ua.restaurant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ua.restaurant.entity.Categories;

/**
 * Repository interface for managing {@link Categories} entities in the database.
 */
public interface CategoriesRepository extends JpaRepository<Categories, Long> {
}
